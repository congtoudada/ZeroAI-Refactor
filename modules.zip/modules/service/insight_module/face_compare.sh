#!/usr/bin/env bash

image_file1="data/test_image/test1.jpg"
image_file2="data/test_image/test2.jpg"
python face_compare.py --image_file1 $image_file1 --image_file2 $image_file2